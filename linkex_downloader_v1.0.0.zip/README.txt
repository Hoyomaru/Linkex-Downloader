Linkex Downloader v1.0.0

1. Tampermonkeyで現在のLinkex Downloaderスクリプトを開きます。
2. 中身を linkex_downloader_v1.0.0.user.js で置き換えて保存します。
3. https://disk.linkex.io/ を再読み込みします。

安全設計:
- 1ファイルずつ共有→自領域へ一時コピー
- コピー先IDを一意に確定
- ローカル保存後にCDN実サイズを検証
- LOCAL_COMMITTEDかつ所有権確定済みID 1件だけ削除
- copy/delete結果不明時は盲目的に再送しない
- Queueは再読み込み後に状態照合して再開可能

診断ログ:
UIの「診断ログを保存」からJSONを書き出せます。認証Token・共有Token・署名付きURLは伏せます。
